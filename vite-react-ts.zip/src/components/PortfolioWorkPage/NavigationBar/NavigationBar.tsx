import { memo } from 'react';
import type { FC, ReactNode } from 'react';

import resets from '../../_resets.module.css';
import classes from './NavigationBar.module.css';

interface Props {
  className?: string;
  text?: {
    work?: ReactNode;
    about?: ReactNode;
    contact?: ReactNode;
  };
}
/* @figmaId 62:35 */
export const NavigationBar: FC<Props> = memo(function NavigationBar(props = {}) {
  return (
    <div className={`${resets.storybrainResets} ${classes.root}`}>
      <div className={classes.nav}>
        <div className={classes.logo}>
          <div className={classes.tHETIMELINEPROJECTS}>
            <div className={classes.textBlock}>THE </div>
            <div className={classes.textBlock2}>TIMELINE</div>
            <div className={classes.textBlock3}>PROJECTS</div>
          </div>
        </div>
        <div className={classes.menu}>
          <div className={classes.work}>
            {props.text?.work != null ? props.text?.work : <div className={classes.work2}>Work</div>}
          </div>
          <div className={classes.about}>
            {props.text?.about != null ? props.text?.about : <div className={classes.about2}>About</div>}
          </div>
          <div className={classes.contact}>
            {props.text?.contact != null ? props.text?.contact : <div className={classes.contact2}>Contact</div>}
          </div>
        </div>
      </div>
    </div>
  );
});
