import { memo } from 'react';
import type { FC } from 'react';

import resets from '../_resets.module.css';
import { NavigationBar } from './NavigationBar/NavigationBar';
import classes from './PortfolioWorkPage.module.css';

interface Props {
  className?: string;
}
/* @figmaId 3:210 */
export const PortfolioWorkPage: FC<Props> = memo(function PortfolioWorkPage(props = {}) {
  return (
    <div className={`${resets.storybrainResets} ${classes.root}`}>
      <div className={classes.footer}>
        <div className={classes.name}>
          <div className={classes.nuriaQuero2022}>Jane Doe ⏤ 2022</div>
        </div>
        <div className={classes.socialLinks}>
          <div className={classes.instagram}>Instagram</div>
          <div className={classes.linkedin}>Linkedin</div>
          <div className={classes.twitter}>Twitter</div>
        </div>
      </div>
      <div className={classes.body}>
        <div className={classes.project_Details}>
          <div className={classes.description}>
            <div className={classes.headline}>
              <div className={classes.frame4}>
                <div className={classes.frame3}>
                  <div className={classes.bookFormatingNotion}>Book Formating (Notion)</div>
                  <div className={classes.UnleashingYourStudentPotential}>
                    ‘Unleashing your Student Potential’ is a book I formated. This was an ai briefed project.
                  </div>
                </div>
              </div>
            </div>
            <div className={classes.details}>
              <div className={classes.role}>
                <div className={classes.clientBrief}>Client Brief:</div>
                <div className={classes.loremIpsumDolorSitAmetConsecte}>
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et
                  dolore magna aliqua.{' '}
                </div>
              </div>
              <div className={classes.client}>
                <div className={classes.cLIENT}>CLIENT</div>
                <div className={classes.openAi}>Open Ai</div>
              </div>
              <div className={classes.project}>
                <div className={classes.pROJECTTYPE}>PROJECT TYPE</div>
                <div className={classes.bookDesignBookFormating}>
                  <div className={classes.textBlock}>Book Design</div>
                  <div className={classes.textBlock2}>Book Formating</div>
                </div>
              </div>
            </div>
          </div>
          <div className={classes.image}></div>
        </div>
      </div>
      <div className={classes.body2}>
        <div className={classes.project_Details2}>
          <div className={classes.description2}>
            <div className={classes.headline2}>
              <div className={classes.frame42}>
                <div className={classes.frame32}>
                  <div className={classes.bookFormatingNotion2}>Book Formating (Notion)</div>
                  <div className={classes.UnleashingYourStudentPotential2}>
                    ‘Unleashing your Student Potential’ is a book I formated. This was an ai briefed project.
                  </div>
                </div>
              </div>
            </div>
            <div className={classes.details2}>
              <div className={classes.role2}>
                <div className={classes.clientBrief2}>Client Brief:</div>
                <div className={classes.loremIpsumDolorSitAmetConsecte2}>
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et
                  dolore magna aliqua.{' '}
                </div>
              </div>
              <div className={classes.client2}>
                <div className={classes.cLIENT2}>CLIENT</div>
                <div className={classes.openAi2}>Open Ai</div>
              </div>
              <div className={classes.project2}>
                <div className={classes.pROJECTTYPE2}>PROJECT TYPE</div>
                <div className={classes.bookDesignBookFormating2}>
                  <div className={classes.textBlock3}>Book Design</div>
                  <div className={classes.textBlock4}>Book Formating</div>
                </div>
              </div>
            </div>
          </div>
          <div className={classes.image2}></div>
        </div>
      </div>
      <div className={classes.body3}>
        <div className={classes.project_Details3}>
          <div className={classes.image3}></div>
          <div className={classes.description3}>
            <div className={classes.headline3}>
              <div className={classes.frame43}>
                <div className={classes.frame33}>
                  <div className={classes.bookFormatingNotion3}>Book Formating (Notion)</div>
                  <div className={classes.UnleashingYourStudentPotential3}>
                    ‘Unleashing your Student Potential’ is a book I formated. This was an ai briefed project.
                  </div>
                </div>
              </div>
            </div>
            <div className={classes.details3}>
              <div className={classes.role3}>
                <div className={classes.clientBrief3}>Client Brief:</div>
                <div className={classes.loremIpsumDolorSitAmetConsecte3}>
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et
                  dolore magna aliqua.{' '}
                </div>
              </div>
              <div className={classes.client3}>
                <div className={classes.cLIENT3}>CLIENT</div>
                <div className={classes.openAi3}>Open Ai</div>
              </div>
              <div className={classes.project3}>
                <div className={classes.pROJECTTYPE3}>PROJECT TYPE</div>
                <div className={classes.bookDesignBookFormating3}>
                  <div className={classes.textBlock5}>Book Design</div>
                  <div className={classes.textBlock6}>Book Formating</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <NavigationBar
        text={{
          work: <div className={classes.work}>Work</div>,
          about: <div className={classes.about}>About</div>,
          contact: <div className={classes.contact}>Contact</div>,
        }}
      />
    </div>
  );
});
